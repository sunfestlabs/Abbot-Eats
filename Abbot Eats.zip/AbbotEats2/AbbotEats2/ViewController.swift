//
//  ViewController.swift
//  AbbotEats2
//
//  Created by MacUser on 2/20/17.
//  Copyright © 2017 MacUser. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {
    
    @IBAction func notify(_ sender: Any) {

        let content = UNMutableNotificationContent()
        content.title = "Test Notification"
        content.subtitle = ""
        content.body = "You clicked the button 5 seconds ago"
        content.sound = UNNotificationSound.default()
        content.badge = 10
        
        let imageName = "applelogo"
        guard let imageURL = Bundle.main.url(forResource: imageName, withExtension: "png") else { return }
        let attachment = try! UNNotificationAttachment(identifier: imageName, url: imageURL, options: .none)
        content.attachments = [attachment]
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let request = UNNotificationRequest(identifier: "testNotification", content: content, trigger: trigger)
        let center = UNUserNotificationCenter.current()
        center.add(request) { (error : Error?) in
            if let error = error {
                print("error: \(error)")
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (success, error) in
            if success {
                print("success")
            } else {
                print("error")
            }
        }
        
        
        
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

