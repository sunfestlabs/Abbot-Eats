//
//  ViewController.swift
//  AbbotEats
//
//  Created by MacUser on 2/6/17.
//  Copyright © 2017 MacUser. All rights reserved.
//

import UIKit
class ViewController: UIViewController,  UIPickerViewDelegate, UIPickerViewDataSource{
    @IBOutlet weak var OrderOutButton:UIButton!
    @IBOutlet weak var places: UIPickerView!
    @IBOutlet weak var go: UIButton!
    
     let pickerData = ["Dominos","Supreme","Szechuan","Front Row","Pad Thai","Penang","Pine Garden"]
    override func viewDidLoad() {
        super.viewDidLoad()
        places.delegate = self
        places.dataSource = self
    }
    @IBAction func Go(_ sender: Any) {
    }
    
    
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//MARK: Delegates
    //MARK: Data Sources
    func numberOfComponents(in pickerView:UIPickerView)-> Int{
        return 1
    }
    func pickerView(_ pickerView:UIPickerView,numberOfRowsInComponent component:Int)-> Int{
        return pickerData.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent: Int)-> String?{
        return pickerData[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        go.setTitle("Let's Order " + pickerData[row]+"!", for: .normal)
    }
}

