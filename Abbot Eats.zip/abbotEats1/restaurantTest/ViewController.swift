//
//  ViewController.swift
//  restaurantTest
//
//  Created by Chris Nivera on 2/22/17.
//  Copyright © 2017 CTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    
    //what I want to do anyway:
    //do a bunch of if statements, basically saying depending on how far you wanna walk,
    
    @IBOutlet weak var picker: UIPickerView!
    
    @IBOutlet weak var spend: UILabel!
    
    @IBOutlet weak var stepper: UIStepper!
    
    @IBOutlet weak var peopleStepper: UIStepper!
    
    @IBOutlet weak var peopleNum: UILabel!
    
    @IBOutlet weak var find: UIButton!
    
    @IBOutlet weak var hunger: UILabel!
    
    @IBOutlet weak var hungerStepper: UIStepper!

    
    var currentWeather: String = "Sunny"
    
    //var contenders: [String] = []
    
    
    // szechuan, penang, mcdonalds, pad thai, dominos, front row, las olas, lexies, green bean, station 19, 11 water street, epoch, laney and lu, stillwells, pine garden, me and ollies, mexico lindo, supreme
    
    @IBAction func hungerStepperAction(_ sender: UIStepper) {
        
        if Int(sender.value) == 1{
            
            hunger.text = "Mildly"
            
        }
        
        else if Int(sender.value) == 2{
            
            hunger.text = "Moderately"
            
        }
        
        else if Int(sender.value) == 3{
            
            hunger.text = "Starving"
            
        }
        
    }
    
    
    
    @IBAction func peopleStepperAction(_ sender: UIStepper) {
        
        peopleNum.text = Int(sender.value).description
        
        
    }
    
    
    @IBAction func stepperAction(_ sender: UIStepper) {
        
        if Int(sender.value) == 1{
            
            spend.text = "$"
            
        }
        
        else if Int(sender.value) == 2{
            
            spend.text = "$$"
            
        }
        
        else if Int(sender.value) == 3{
            
            spend.text = "$$$"
            
        }
        
    }
    
    
    var currentRow: String = ""
    
    let pickerData = ["Sunny", "Cloudy", "Rainy", "Snowy"]

    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        picker.delegate = self
        picker.dataSource = self
        
    
        find.layer.cornerRadius = 4
        
        stepper.wraps = true
        stepper.autorepeat = true
        stepper.maximumValue = 3
    
        peopleStepper.wraps = true
        peopleStepper.autorepeat = true
        peopleStepper.maximumValue = 10

        
        hungerStepper.wraps = true
        hungerStepper.autorepeat = true
        hungerStepper.maximumValue = 3

        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
        
    }
    
    
    // DataSource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    // Delegate
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        currentRow = pickerData[row]
        return pickerData[row]
        
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        currentWeather = pickerData[row]
    }
    


    @IBAction func find(_ sender: Any) {
        
        
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        
      

        //choose Penang's
        if spend.text == "$" && Int(peopleNum.text!)! < 5 && hunger.text == "Mildly"{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "penang") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
            vc.view.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "penang"))
            
        }
        
    
        //chose Pad Thai
        if currentWeather.range(of: "Sunny") != nil || currentWeather.range(of: "Cloudy") != nil && spend.text == "$$" && Int(peopleNum.text!)! < 5 && hunger.text == "Moderately"{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "padthai") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
            
        //choose Domino's
        if spend.text == "$" && hunger.text == "Starving" && Int(peopleNum.text!)! > 1{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "dominos") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        //choose Front Row
        if spend.text == "$$$" && hunger.text == "Moderately" {
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "frontrow") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        //choose Lexie's
        if currentWeather.range(of: "Sunny") != nil || currentWeather.range(of: "Cloudy") != nil && spend.text == "$$" && Int(peopleNum.text!)! < 5{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "lexies") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        //choose Szechuan
        if spend.text == "$" && Int(peopleNum.text!)! > 1 {
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "szechuan") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
            vc.view.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "tso2"))
            
        }
        
        
        //choose Las Olas
        if currentWeather.range(of: "Sunny") != nil || currentWeather.range(of: "Cloudy") != nil && spend.text == "$" && hunger.text == "Moderately" || hunger.text == "Mildly"{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "laso") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        //choose McDonalds
        if currentWeather.range(of: "Sunny") != nil && spend.text == "$" && hunger.text == "Moderately" || hunger.text == "Mildly"{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "mcdonalds") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        //choose Green Bean
         if spend.text == "$" || spend.text == "$$" && Int(peopleNum.text!)! < 5{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "greenbean") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        //choose Station 19
         if spend.text == "$$" || spend.text == "$$$" && Int(peopleNum.text!)! < 5{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "station19") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        //choose 11 Water Street
        if spend.text == "$$$" && hunger.text == "Moderately" || hunger.text == "Mildly" && Int(peopleNum.text!)! < 5{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "11waterst") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        //choose Pine Garden
         if currentWeather.range(of: "Sunny") != nil || currentWeather.range(of: "Cloudy") != nil && spend.text == "$$" && hunger.text == "Moderately"{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "pinegarden") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        //choose Stilwells
         if currentWeather.range(of: "Sunny") != nil || currentWeather.range(of: "Cloudy") != nil && spend.text == "$" && hunger.text == "Mildly"{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "stlllwells") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        //choose Laney and Lu
         if spend.text == "$$" && hunger.text == "Mildly" && Int(peopleNum.text!)! < 3{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "laneyandlu") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        
        //choose Me and Ollie's
         if spend.text == "$" && hunger.text == "Mildly" && Int(peopleNum.text!)! < 9{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "meandollies") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        
        //choose Mexico Lindo
        if currentWeather.range(of: "Sunny") != nil || currentWeather.range(of: "Cloudy") != nil && spend.text == "$$" && hunger.text == "Moderately" && Int(peopleNum.text!)! < 6{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "mexicolindo") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        
        //choose Supreme's
        if spend.text == "$$" && hunger.text == "Moderately" || hunger.text == "Starving"{
            
            let vc: ChoiceViewController = storyboard.instantiateViewController(withIdentifier: "supremes") as! ChoiceViewController
            
            self.present(vc, animated: true, completion: nil)
            
        }
        
        
        
        
        
        
    }
    
    
}

